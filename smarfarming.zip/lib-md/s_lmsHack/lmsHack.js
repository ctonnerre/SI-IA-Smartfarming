// lmsHacks.js Placeholder surchargé par le packaging SCORM.
